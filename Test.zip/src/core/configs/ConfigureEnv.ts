export default {
  PURE_URL: '',
  BASE_URL: '',
  UPLOAD_URL: '',
  MAP_TOKEN: 'pk.eyJ1IjoiYW1pcnJzdG0iLCJhIjoiY2txNXk0MWZmMTFwdzJ2bzYyZmUzNnJheiJ9.eQ7kIkXYT-XKfhAs9_G0zA',
};
