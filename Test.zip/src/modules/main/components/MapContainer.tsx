import Env from '@config/ConfigureEnv';
import React, { ReactElement, useState } from 'react';
import ReactMapGL, { Layer, Popup, Source } from 'react-map-gl';

import { IMapContainerProps, IMapViewport } from '../types/Map_T';
import Styles from './styles/MapContainer.style';

export default function MapContainer({
                                       onClick,
                                       showPopup,
                                       togglePopup,
                                       sourceData = { type: 'raster' },
                                       popupData = { longitude: 0, latitude: 0 },
                                     }: IMapContainerProps): ReactElement {
  const [viewport, setViewport] = useState<IMapViewport>({ longitude: -85.595, latitude: 44.775, zoom: 9 });

  return (
    <Styles.MainContainer>
      <ReactMapGL
        {...viewport}
        width='100%'
        height='100%'
        onClick={onClick}
        onViewportChange={setViewport}
        mapboxApiAccessToken={Env.MAP_TOKEN}
        mapStyle='mapbox://styles/mapbox/satellite-v9'
      >
        <Source {...sourceData}>
          <Layer id='raster-layer' type='raster' paint={{}} />
        </Source>

        {
          showPopup &&
          <Popup
            anchor='top'
            closeOnClick={false}
            latitude={popupData.latitude}
            longitude={popupData.longitude}
            onClose={() => togglePopup(false)}
          >
            <div>Pixs Here : {popupData?.latitude}</div>
          </Popup>
        }
      </ReactMapGL>
    </Styles.MainContainer>
  );
}
