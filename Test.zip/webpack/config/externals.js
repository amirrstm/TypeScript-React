export const externalItems = {
    // jquery: 'jQuery'
};
