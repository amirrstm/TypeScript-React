# Test Project

## Quick start

To run this locally:

1. Install all dependencies using `yarn` or `npm install`
2. Start the development server using `yarn start` or `npm run start`
3. Open up [http://localhost:8080](http://localhost:8080)
